<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'BAD_REQUEST', 'message' => 'Invalid JSON body']);
    exit;
}

$username   = isset($data['username']) ? trim($data['username']) : '';
$subject    = isset($data['subject']) ? trim($data['subject']) : '';
$answers    = isset($data['answers']) ? $data['answers'] : null;
$suggestion = isset($data['suggestion']) ? trim($data['suggestion']) : null;

if ($username === '' || $subject === '' || !is_array($answers) || empty($answers)) {
    http_response_code(422);
    echo json_encode(['error' => 'VALIDATION_FAILED']);
    exit;
}

$answersJson = json_encode($answers, JSON_UNESCAPED_UNICODE);

$stmt = $pdo->prepare('INSERT INTO feedback_responses (username, subject, answers, suggestion) VALUES (?, ?, ?, ?)');
$stmt->execute([$username, $subject, $answersJson, $suggestion]);

echo json_encode(['ok' => true, 'id' => $pdo->lastInsertId()]);
