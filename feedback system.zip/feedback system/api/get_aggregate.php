<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

$stmt = $pdo->query('SELECT subject, answers FROM feedback_responses');
$agg = [];
while ($row = $stmt->fetch()) {
    $subject = $row['subject'];
    $answers = json_decode($row['answers'], true);
    if (!isset($agg[$subject])) {
        $agg[$subject] = [
            'excellent' => 0,
            'verygood'  => 0,
            'good'      => 0,
            'fair'      => 0,
            'poor'      => 0,
        ];
    }
    if (is_array($answers)) {
        foreach ($answers as $q => $rating) {
            if (isset($agg[$subject][$rating])) {
                $agg[$subject][$rating]++;
            }
        }
    }
}

echo json_encode(['data' => $agg]);

