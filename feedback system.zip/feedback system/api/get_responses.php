<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

$subject = isset($_GET['subject']) ? trim($_GET['subject']) : '';
if ($subject === '') {
  $stmt = $pdo->query('SELECT username, subject, answers, suggestion, created_at FROM feedback_responses ORDER BY created_at DESC');
} else {
  $stmt = $pdo->prepare('SELECT username, subject, answers, suggestion, created_at FROM feedback_responses WHERE subject = ? ORDER BY created_at DESC');
  $stmt->execute([$subject]);
}

$list = [];
while ($row = $stmt->fetch()) {
  $answers = json_decode($row['answers'], true);
  if (!is_array($answers)) $answers = [];
  $list[] = [
    'username' => $row['username'],
    'subject' => $row['subject'],
    'answers' => $answers,
    'suggestion' => $row['suggestion'],
    'date' => $row['created_at']
  ];
}

echo json_encode(['data' => $list]);
