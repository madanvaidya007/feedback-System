<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

$stmt = $pdo->prepare('SELECT COUNT(*) AS c FROM users WHERE role = ?');
$stmt->execute(['admin']);
$row = $stmt->fetch();
$exists = $row && (int)$row['c'] > 0;
echo json_encode(['exists'=>$exists]);
