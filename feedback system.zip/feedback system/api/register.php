<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) { http_response_code(400); echo json_encode(['error'=>'BAD_REQUEST']); exit; }

$username = isset($data['username']) ? trim($data['username']) : '';
$email = isset($data['email']) ? trim($data['email']) : '';
$mobile = isset($data['mobile']) ? trim($data['mobile']) : '';
$password = isset($data['password']) ? $data['password'] : '';
$role = isset($data['role']) ? trim($data['role']) : 'student';

if ($username === '' || $email === '' || $mobile === '' || $password === '' || ($role !== 'student' && $role !== 'admin')) {
  http_response_code(422); echo json_encode(['error'=>'VALIDATION_FAILED']); exit;
}

$stmt = $pdo->prepare('SELECT COUNT(*) AS c FROM users WHERE role = ?');
$stmt->execute(['admin']);
$row = $stmt->fetch();
if ($role === 'admin' && $row && (int)$row['c'] > 0) { http_response_code(409); echo json_encode(['error'=>'ADMIN_EXISTS']); exit; }

$stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1');
$stmt->execute([$username, $email]);
if ($stmt->fetch()) { http_response_code(409); echo json_encode(['error'=>'USER_EXISTS']); exit; }

$hash = password_hash($password, PASSWORD_BCRYPT);
$stmt = $pdo->prepare('INSERT INTO users (username,email,mobile,password_hash,role) VALUES (?,?,?,?,?)');
$stmt->execute([$username, $email, $mobile, $hash, $role]);
$id = $pdo->lastInsertId();

echo json_encode(['ok'=>true,'user'=>['id'=>$id,'username'=>$username,'email'=>$email,'mobile'=>$mobile,'role'=>$role]]);
