<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) { http_response_code(400); echo json_encode(['error'=>'BAD_REQUEST']); exit; }

$username = isset($data['username']) ? trim($data['username']) : '';
$old = isset($data['old_password']) ? $data['old_password'] : '';
$new = isset($data['new_password']) ? $data['new_password'] : '';
if ($username === '' || $old === '' || $new === '' || strlen($new) < 5) { http_response_code(422); echo json_encode(['error'=>'VALIDATION_FAILED']); exit; }

$stmt = $pdo->prepare('SELECT id, password_hash FROM users WHERE username = ? LIMIT 1');
$stmt->execute([$username]);
$user = $stmt->fetch();
if (!$user) { http_response_code(404); echo json_encode(['error'=>'NOT_FOUND']); exit; }
if (!password_verify($old, $user['password_hash'])) { http_response_code(401); echo json_encode(['error'=>'INVALID_OLD_PASSWORD']); exit; }

$hash = password_hash($new, PASSWORD_BCRYPT);
$stmt = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
$stmt->execute([$hash, $user['id']]);

echo json_encode(['ok'=>true]);
