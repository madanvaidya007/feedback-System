<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

$stmt = $pdo->query('SELECT username, subject, suggestion, created_at FROM feedback_responses WHERE suggestion IS NOT NULL AND suggestion <> "" ORDER BY created_at DESC');
$list = [];
while ($row = $stmt->fetch()) {
    $list[] = [
        'user' => $row['username'],
        'subject' => $row['subject'],
        'text' => $row['suggestion'],
        'date' => $row['created_at']
    ];
}

echo json_encode(['data'=>$list]);
