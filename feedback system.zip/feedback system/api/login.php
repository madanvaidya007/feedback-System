<?php
header('Content-Type: application/json');
require __DIR__ . '/db.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) { http_response_code(400); echo json_encode(['error'=>'BAD_REQUEST']); exit; }

$username = isset($data['username']) ? trim($data['username']) : '';
$password = isset($data['password']) ? $data['password'] : '';
if ($username === '' || $password === '') { http_response_code(422); echo json_encode(['error'=>'VALIDATION_FAILED']); exit; }

$stmt = $pdo->prepare('SELECT id, username, email, mobile, password_hash, role FROM users WHERE username = ? LIMIT 1');
$stmt->execute([$username]);
$user = $stmt->fetch();
if (!$user) { http_response_code(401); echo json_encode(['error'=>'INVALID_CREDENTIALS']); exit; }

if (!password_verify($password, $user['password_hash'])) { http_response_code(401); echo json_encode(['error'=>'INVALID_CREDENTIALS']); exit; }

unset($user['password_hash']);
echo json_encode(['ok'=>true,'user'=>$user]);
